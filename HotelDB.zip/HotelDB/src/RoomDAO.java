import java.sql.*;

public class RoomDAO {
    public void addRoom(String roomNumber, String type, double price) {
        String query = "INSERT INTO Rooms (room_number, type, price) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, roomNumber);
            stmt.setString(2, type);
            stmt.setDouble(3, price);
            stmt.executeUpdate();
            System.out.println("Room added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //View All Rooms
    public void getAllrooms() {
        String query = "SELECT * FROM Rooms";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        ", Room Number: " + rs.getString("room_number") +
                        ", Type: " + rs.getString("type") +
                        ", Price: " + rs.getDouble("price"));
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Update Room Price
    public void updateRoomPrice(String roomNumber, double newPrice) {
        String query = "UPDATE Rooms SET PRICE = ? WHERE room_number = ?";

        try(Connection conn = DatabaseConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, newPrice);
            stmt.setString(2, roomNumber);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Room price updated successfully.");
            } else {
                System.out.println("Room not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Delete Room
    public void deleteRoom(String roomNumber) {
        String query = "DELETE FROM Rooms WHERE room_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, roomNumber);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Room deleted successfully.");
            } else {
                System.out.println("Room not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
