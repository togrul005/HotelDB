import java.util.Scanner;

public class HotelManagementApp {
    public static void main(String[] args) {
        RoomDAO roomDAO = new RoomDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Hotel Management System ---");
            System.out.println("1. Add Room");
            System.out.println("2. View Rooms");
            System.out.println("3. Update Room Price");
            System.out.println("4. Delete Room");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");


            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter room number: ");
                    String roomNum = scanner.next();
                    System.out.print("Enter room type: ");
                    String type = scanner.next();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    roomDAO.addRoom(roomNum, type, price);
                    break;

                case 2:
                    roomDAO.getAllrooms();
                    break;

                case 3:
                    System.out.print("Enter room number to update: ");
                    String updateNum = scanner.next();
                    System.out.print("Enter new price: ");
                    double newPrice = scanner.nextDouble();
                    roomDAO.updateRoomPrice(updateNum, newPrice);
                    break;

                case 4:
                    System.out.print("Enter room number to delete: ");
                    String deleteNum = scanner.next();
                    roomDAO.deleteRoom(deleteNum);
                    break;

                case 5:
                    System.out.println("Exiting program...");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
